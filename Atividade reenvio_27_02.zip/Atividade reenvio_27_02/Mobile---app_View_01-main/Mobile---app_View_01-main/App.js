/*
Fabio Rodrigues
Felipe Luz
Gabriel Ozório
Jhonata Lima
Vinicius Cerqueira Silva
*/

import React from "react";
import { View, Text, Dimensions } from "react-native";

function App() {
  const { height: screenHeight } = Dimensions.get("window");

  return (
    <View
      style={{
        backgroundColor: "firebrick",
        height: screenHeight, // 100% da tela
        width: 300,          // 300px
      }}
    >
      
      <View
        style={{
          backgroundColor: "aquamarine",
          width: "100%",
          height: screenHeight * 0.2, // 20% da tela
        }}
      >
        <Text>COMPONENTE VIEW</Text>
        <Text>Vinicius Cerqueira Silva</Text>
        <Text>02/02/1999</Text>
      </View>

      
      <View
        style={{
          backgroundColor: "green",
          height: screenHeight * 0.7, // 70% da tela
          width: 100,                 // 100px
        }}
      >
        <Text style={{ color: "white" }}>COMPONENTE VIEW</Text>
        <Text style={{ color: "white" }}>Vinicius Cerqueira Silva</Text>
        <Text style={{ color: "white" }}>02/02/1999</Text>
      </View>

      {/* View Vermelha */}
      <View
        style={{
          backgroundColor: "crimson",
          height: screenHeight * 0.1, // 10% da tela
          width: 200,                 // 200px
        }}
      >
        <Text>COMPONENTE VIEW</Text>
        <Text>Vinicius Cerqueira Silva</Text>
        <Text>02/02/1999</Text>
      </View>
    </View>
  );
}

export default App;